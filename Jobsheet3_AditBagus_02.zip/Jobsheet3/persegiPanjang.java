public class persegiPanjang {
    public int panjang;
    public int lebar;
    
    public persegiPanjang(int p, int l){
        panjang = p;
        lebar = l;
    }
}
