public class Pelanggan {
    String namaPelanggan, acara, nomorTelepon;
    int jumlahTamu;

    public void tampilkanPesanan(){
        System.out.println("\n=================================");
        System.out.println("Nama Pelanggan: " + namaPelanggan);
        System.out.println("Acara yang digelar: : " + acara);
        System.out.println("Nomor Telepon : " + nomorTelepon);
        System.out.println("Jumlah Tamu: " + jumlahTamu);
        System.out.println("=================================");
    }

    
}
