package Jobsheet2;

public class PiramidMain {
    public static void main(String[] args) {
        Piramid piramid1 = new Piramid();
        piramid1.panjangSisiPersegi = 6;
        piramid1.panjangRusukSegitiga = 12;
        piramid1.tinggi = 9;

        piramid1.tampilHasil();
    }
}